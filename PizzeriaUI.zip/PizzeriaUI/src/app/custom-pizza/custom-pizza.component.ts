import {Component,OnInit} from '@angular/core';
import {FormControl} from '@angular/forms';
import { CustomPizzaItem, CustomizationType } from '../models/custom-pizza-item';
import { PizzaService } from '../services/pizza.service';
import { CartService } from '../services/cart.service';
import { itemCategory } from 'src/app/models/pizza';


@Component({
  selector: 'custom-pizza',
  templateUrl: './custom-pizza.component.html',
  styleUrls: ['./custom-pizza.component.css']
})
export class CustomPizzaComponent implements OnInit {

   CustomPizzaItem : CustomPizzaItem[] | undefined;

  toppings = new FormControl();
  toppingList: CustomPizzaItem[] | undefined;

  sauces = new FormControl();
  saucesList: CustomPizzaItem[] | undefined;

  crust = new FormControl();
  crustList: CustomPizzaItem[] | undefined;

  constructor(private pizzaService: PizzaService, private cartService : CartService) {}

  ngOnInit() {
    this.pizzaService.getCustomItems().subscribe((data: CustomPizzaItem[]) => {
      this.CustomPizzaItem = data;
      this.buildToppingsList();
      this.buildSaucesList();
      this.buildCrustList();
    });
  }

  buildToppingsList(){
    this.toppingList = this.CustomPizzaItem?.filter(x=>x.type == CustomizationType.Topping);
  }
  buildSaucesList(){
    this.saucesList = this.CustomPizzaItem?.filter(x=>x.type == CustomizationType.Sauce);
  }
  buildCrustList(){
    this.crustList = this.CustomPizzaItem?.filter(x=>x.type == CustomizationType.Crust);
  }

  onCurstChange(curst : any){
    this.cartService.setCartItem(curst, itemCategory.Custom);
  }

  onSauceChange(sauce : any){
    this.cartService.setCartItem(sauce, itemCategory.Custom);
  }

  onToppingChange(topping : any){
    this.cartService.setCartItem(topping, itemCategory.Custom);
  }

}



