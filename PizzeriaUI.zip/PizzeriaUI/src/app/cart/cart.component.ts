import { Component, OnInit } from '@angular/core';
import { Pizza } from '../models/pizza';
import { CartService } from '../services/cart.service';


@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  totalAmount = 0;
  pizzaMenu : Pizza[] | undefined ;
  cartDetails : any = [];


  constructor(private cartService : CartService) { }

  ngOnInit() {
     console.log("cart component")
     this.cartService.getCartItem().subscribe((pizza:any) => {
      this.cartDetails.push({"id": pizza.id, "name": pizza.name,"price":pizza.price})
      this.totalAmount +=pizza.price;
    });
  }

  orderNow(cartDetails:any[]) {
    this.cartService.postOrder(cartDetails).subscribe((data:any) =>{
     alert("your order is sucessfully placed");
     this.cartDetails = [];
    })
  }
}
