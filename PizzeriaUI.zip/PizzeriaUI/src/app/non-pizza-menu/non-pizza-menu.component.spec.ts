import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NonPizzaMenuComponent } from './non-pizza-menu.component';

describe('NonPizzaMenuComponent', () => {
  let component: NonPizzaMenuComponent;
  let fixture: ComponentFixture<NonPizzaMenuComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NonPizzaMenuComponent]
    });
    fixture = TestBed.createComponent(NonPizzaMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
