import { Component, OnInit } from '@angular/core';
import { NonPizzaItem } from '../models/non-pizza-item';
import { PizzaService } from '../services/pizza.service';
import { CartService } from '../services/cart.service';
import { itemCategory } from 'src/app/models/pizza';


@Component({
  selector: 'non-pizza-menu',
  templateUrl: './non-pizza-menu.component.html',
  styleUrls: ['./non-pizza-menu.component.css']
})
export class NonPizzaMenuComponent implements OnInit {
    
  nonPizzaMenu : NonPizzaItem[] | undefined ;

  constructor(private pizzaService: PizzaService, private cartService : CartService) { }

  ngOnInit() {
    this.pizzaService.getNonPizzaMenuItems().subscribe((data: NonPizzaItem[]) => {
      this.nonPizzaMenu = data;
    });
  }

  addToMyCart = (menu: any) => {
    this.cartService.setCartItem(menu, itemCategory.NonPizza);
    //this.addToMyCartEvent.emit(menu);
  }
}
