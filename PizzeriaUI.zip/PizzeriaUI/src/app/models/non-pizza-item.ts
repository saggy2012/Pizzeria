export class NonPizzaItem {
    "id": number;
    "name": string;
    "price": number;
    "imgUrl":string;
}