export class CustomPizzaItem {
    "id": number;
    "name": string;
    "price": number;
    "type": number;
    "imgUrl":string;

}

export enum CustomizationType {
    Crust = 0,
    Topping,
    Sauce,
    Cheese
}