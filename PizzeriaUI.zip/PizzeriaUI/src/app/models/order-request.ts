export class OrderRequest {
    pizzaIds!: Array<number>;
    customizationIds!: number[];
    nonPizzaItems!: number[];
}
