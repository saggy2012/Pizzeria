export class Pizza {
    "id": number;
    "name": string;
    "price": number;
    "imgUrl":string;
}

export enum itemCategory {
    Pizza = 1,
    NonPizza = 2,
    Custom = 3
}
