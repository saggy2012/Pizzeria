import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { Pizza, itemCategory } from '../models/pizza';
import { PizzaService } from '../services/pizza.service';
import { CartService } from '../services/cart.service';


@Component({
  selector: 'pizz-menu-item',
  templateUrl: './pizz-menu-item.component.html',
  styleUrls: ['./pizz-menu-item.component.css']
})
export class PizzMenuItemComponent implements OnInit  {

  pizzaMenu : Pizza[] | undefined ;
  @Output() addToMyCartEvent = new EventEmitter();

  constructor(private pizzaService: PizzaService, private cartService : CartService) { }

  ngOnInit() {
    this.pizzaService.getPizzaMenuItems().subscribe((data: Pizza[]) => {
      this.pizzaMenu = data;
    });
  }

  addToMyCart = (menu: any) => {
    this.cartService.setCartItem(menu, itemCategory.Pizza);
  }

}
