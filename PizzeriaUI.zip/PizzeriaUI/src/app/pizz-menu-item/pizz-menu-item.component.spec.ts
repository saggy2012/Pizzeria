import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PizzMenuItemComponent } from './pizz-menu-item.component';

describe('PizzMenuItemComponent', () => {
  let component: PizzMenuItemComponent;
  let fixture: ComponentFixture<PizzMenuItemComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PizzMenuItemComponent]
    });
    fixture = TestBed.createComponent(PizzMenuItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
