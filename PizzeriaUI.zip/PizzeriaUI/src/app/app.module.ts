import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { MatCardModule } from '@angular/material/card';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PizzMenuItemComponent } from './pizz-menu-item/pizz-menu-item.component';
import { NonPizzaMenuComponent } from './non-pizza-menu/non-pizza-menu.component';
import { CartComponent } from './cart/cart.component';
import { CustomPizzaComponent } from './custom-pizza/custom-pizza.component';


@NgModule({
  declarations: [
    AppComponent,
    PizzMenuItemComponent,
    NonPizzaMenuComponent,
    CartComponent,
    CustomPizzaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    MatCardModule,
    FormsModule,
    ReactiveFormsModule,
    MatCheckboxModule,
    MatSelectModule,
    MatFormFieldModule,
    BrowserAnimationsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
