﻿using Pizzeria.Data.Models;
using Pizzeria.Db.Interface;
using Pizzeria.Service.Interfaces;

namespace Pizzeria.Service
{
    public class NonPizzaItemService : INonPizzaItemService
    {
        private readonly IDataAccess _dataAccess;
        private const string FileName = "nonpizzaitems";

        public NonPizzaItemService(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }

        public async Task<IEnumerable<NonPizzaItem>> GetAllNonPizzaItems()
        {
            var result = await _dataAccess.Get<NonPizzaItem>(FileName);
            return result;
        }
    }
    
}