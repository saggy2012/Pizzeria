﻿using Pizzeria.Data.Models;
using Pizzeria.Db.Interface;
using Pizzeria.Service.Interfaces;

namespace Pizzeria.Service
{
    public class PizzaService : IPizzaService
    {
        private IDataAccess _dataAccess;
        private readonly INonPizzaItemService _nonPizzaItemService;
        private readonly IPizzaCustomizationService _pizzaCustomizationService;
        
        private const string FileName = "Pizzas";
        private const string OrderFileName = "Orders";

        public PizzaService(IDataAccess dataAccess, INonPizzaItemService nonPizzaItemService, IPizzaCustomizationService pizzaCustomizationService)
        {
            _dataAccess = dataAccess;
            _nonPizzaItemService = nonPizzaItemService;
            _pizzaCustomizationService = pizzaCustomizationService;
        }

         public async Task<IEnumerable<Pizza>> GetPizzas()
        {
            return await _dataAccess.Get<Pizza>(FileName);
        }

        public async Task<OrderResponse> Order(OrderRequest orderRequest)
        {
            var pizzas = await GetPizzas();
            int orderTotal = 0;
            foreach (var pizzaId in orderRequest.PizzaIds)
            {
                orderTotal += pizzas.FirstOrDefault(x => x.Id == pizzaId).Price;
            }

            var customizations = await _pizzaCustomizationService.GetAllCustomization();

            foreach (var id in orderRequest.CustomizationIds)
            {
                orderTotal += customizations.FirstOrDefault(x => x.Id == id).Price;
            }

            var nonPizzaItems = await _nonPizzaItemService.GetAllNonPizzaItems();

            foreach (var id in orderRequest.NonPizzaItems)
            {
                orderTotal += nonPizzaItems.FirstOrDefault(x => x.Id == id).Price;
            }

            var newOrderDetails = new OrderResponse
            {
                CustomizationIds = orderRequest.CustomizationIds,
                PizzaIds = orderRequest.PizzaIds,
                NonPizzaItems = orderRequest.NonPizzaItems,
                Total = orderTotal
                
            };

            _dataAccess.Write(OrderFileName, newOrderDetails);

            return newOrderDetails;
        }
    }
}