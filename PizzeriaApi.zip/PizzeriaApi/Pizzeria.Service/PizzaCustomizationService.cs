﻿using Pizzeria.Data.Models;
using Pizzeria.Db.Interface;
using Pizzeria.Service.Interfaces;

namespace Pizzeria.Service
{
    public class PizzaCustomizationService : IPizzaCustomizationService
    {
        private readonly IDataAccess _dataAccess;
        private const string FileName = "customizations";

        public PizzaCustomizationService(IDataAccess dataAccess)
        {
            _dataAccess = dataAccess;
        }

        public async Task<IEnumerable<Customization>> GetAllCustomization()
        {
            var result =  await _dataAccess.Get<Customization>(FileName);
            return result;
        }
    }
}