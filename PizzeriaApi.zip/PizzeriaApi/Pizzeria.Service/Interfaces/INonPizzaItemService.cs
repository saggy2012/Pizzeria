﻿using Pizzeria.Data.Models;

namespace Pizzeria.Service.Interfaces
{
    public interface INonPizzaItemService
    {
        public Task<IEnumerable<NonPizzaItem>> GetAllNonPizzaItems();
    }
}
