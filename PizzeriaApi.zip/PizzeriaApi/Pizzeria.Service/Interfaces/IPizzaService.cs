﻿using Pizzeria.Data.Models;

namespace Pizzeria.Service.Interfaces
{
    public interface IPizzaService
    {
        public Task<IEnumerable<Pizza>> GetPizzas();
        Task<OrderResponse> Order(OrderRequest order);
    }
}
