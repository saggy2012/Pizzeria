﻿using Pizzeria.Data.Models;

namespace Pizzeria.Service.Interfaces
{
    public interface IPizzaCustomizationService
    {
        public Task<IEnumerable<Customization>> GetAllCustomization();
    }
}
