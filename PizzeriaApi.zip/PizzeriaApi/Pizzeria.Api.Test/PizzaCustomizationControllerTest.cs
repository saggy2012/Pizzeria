using Microsoft.AspNetCore.Routing;
using Moq;
using Pizzeria.Common.Data;
using Pizzeria.Data.Models;
using Pizzeria.Service.Interfaces;
using PizzeriaApi.Controllers;
using Shouldly;

namespace Pizzeria.Api.Test
{
    public class PizzaCustomizationControllerTest
    {
        private readonly Mock<IPizzaCustomizationService> _pizzaCustomizationService;
        private readonly PizzaCustomizationController _pizzaCustomizationController;
        public PizzaCustomizationControllerTest()
        {
            _pizzaCustomizationService = new Mock<IPizzaCustomizationService>();
            _pizzaCustomizationController = new PizzaCustomizationController(_pizzaCustomizationService.Object);
        }


        [Fact]
        public async void PizzaCustomizationController_GetAll_ShouldReturnCountWhenhaveData()
        {
            _pizzaCustomizationService.Setup(x => x.GetAllCustomization()).ReturnsAsync(MockData.Customizations);
            var data = await _pizzaCustomizationController.GetAll();
            data.Count().ShouldBe(2);
        }
    }
}