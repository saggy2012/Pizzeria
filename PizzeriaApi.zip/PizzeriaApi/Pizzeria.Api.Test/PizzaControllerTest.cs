using Microsoft.AspNetCore.Routing;
using Moq;
using Pizzeria.Common.Data;
using Pizzeria.Data.Models;
using Pizzeria.Service.Interfaces;
using PizzeriaApi.Controllers;
using Shouldly;

namespace Pizzeria.Api.Test
{
    public class PizzaControllerTest
    {
        private readonly Mock<IPizzaService> _pizzaService;
        private readonly PizzaController _pizzaController;
        public PizzaControllerTest()
        {
            _pizzaService = new Mock<IPizzaService>();
            _pizzaController = new PizzaController(_pizzaService.Object);
        }


        [Fact]
        public async void PizzaController_GetAll_ShouldReturnCountWhenhaveData()
        {
            _pizzaService.Setup(x => x.GetPizzas()).ReturnsAsync(MockData.Pizzas);
            var data = await _pizzaController.GetAll();
            data.Count().ShouldBe(2);
        }

        [Fact]
        public async void PizzaController_PostOrder_ShouldReturnDataOnSuccessfulOrder()
        {
            _pizzaService.Setup(x => x.Order(It.IsAny<OrderRequest>())).ReturnsAsync(new OrderResponse());
            var orderResponse = await _pizzaController.Order(new OrderRequest { CustomizationIds = new int[] { 1 }, PizzaIds = new[] { 1 }, NonPizzaItems = new[] { 1 } });
            orderResponse.Total?.ShouldBeGreaterThan(0);
        }
    }
}