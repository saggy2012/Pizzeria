using Moq;
using Pizzeria.Common.Data;
using Pizzeria.Service.Interfaces;
using PizzeriaApi.Controllers;
using Shouldly;

namespace Pizzeria.Api.Test
{
    public class NonPizzaItemsControllerTest
    {
        private readonly Mock<INonPizzaItemService> _pizzaNonPizzaItemService;
        private readonly NonPizzaItemsController _nonPizzaItemsController;
        public NonPizzaItemsControllerTest()
        {
            _pizzaNonPizzaItemService = new Mock<INonPizzaItemService>();
            _nonPizzaItemsController = new NonPizzaItemsController(_pizzaNonPizzaItemService.Object);
        }


        [Fact]
        public async void NonPizzaIItemController_GetAll_ShouldReturnCountWhenhaveData()
        {
            _pizzaNonPizzaItemService.Setup(x => x.GetAllNonPizzaItems()).ReturnsAsync(MockData.NonPizzaItem);
            var data = await _nonPizzaItemsController.GetAll();
            data.Count().ShouldBe(1);
        }

    }
}