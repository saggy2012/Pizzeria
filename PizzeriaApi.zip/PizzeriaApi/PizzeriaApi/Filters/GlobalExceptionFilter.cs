﻿using Microsoft.AspNetCore.Mvc.Filters;

namespace Pizzeria.Api.Filters
{
    public class GlobalExceptionFilter : IExceptionFilter
    {
        private readonly ILogger _logger;

        public GlobalExceptionFilter(ILogger<GlobalExceptionFilter> logger)
        {
                _logger = logger;
        }
        public void OnException(ExceptionContext context)
        {
            if (context == null)
                throw new ArgumentNullException("context is null");

            _logger.LogError(context.Exception, context.Exception.Message);
        }
    }
}
