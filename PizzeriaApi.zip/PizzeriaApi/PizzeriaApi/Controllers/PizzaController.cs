﻿using Microsoft.AspNetCore.Mvc;
using Pizzeria.Data.Models;
using Pizzeria.Service.Interfaces;

namespace PizzeriaApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PizzaController : Controller
    {
        private readonly IPizzaService _pizzaService;
        public PizzaController(IPizzaService pizzaService)
        {
            _pizzaService = pizzaService;  
        }

        [HttpGet("GetAll")]
        public async Task<IEnumerable<Pizza>> GetAll()
        {
            return await _pizzaService.GetPizzas();
        }

        [HttpPost("Order")]
        public async Task<OrderResponse> Order([FromBody] OrderRequest orderRequest)
        {
            return await _pizzaService.Order(orderRequest);
        }
    }
}
