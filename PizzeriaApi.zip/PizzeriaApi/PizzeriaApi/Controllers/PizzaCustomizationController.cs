﻿using Microsoft.AspNetCore.Mvc;
using Pizzeria.Data.Models;
using Pizzeria.Service.Interfaces;

namespace PizzeriaApi.Controllers
{

    [ApiController]
    [Route("[controller]")]
    public class PizzaCustomizationController : Controller
    {
        private readonly IPizzaCustomizationService _pizzaCustomizationService;
        public PizzaCustomizationController(IPizzaCustomizationService pizzaCustomizationService)
        {
            _pizzaCustomizationService = pizzaCustomizationService;
        }

        [HttpGet("GetAll")]
        public async Task<IEnumerable<Customization>> GetAll()
        {
            return await _pizzaCustomizationService.GetAllCustomization();
        }
    }
}
