﻿using Microsoft.AspNetCore.Mvc;
using Pizzeria.Data.Models;
using Pizzeria.Service.Interfaces;
using System.Data;

namespace PizzeriaApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class NonPizzaItemsController : Controller
    {
        private readonly INonPizzaItemService _nonPizzaItemService;
        public NonPizzaItemsController(INonPizzaItemService nonPizzaItemService) 
        {
         _nonPizzaItemService = nonPizzaItemService;
        }

        [HttpGet("GetAll")]
        public async Task<IEnumerable<NonPizzaItem>> GetAll()
        {
            return await _nonPizzaItemService.GetAllNonPizzaItems();
        }
    }
}
