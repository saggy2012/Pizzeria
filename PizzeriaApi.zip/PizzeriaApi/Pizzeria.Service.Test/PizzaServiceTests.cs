using Moq;
using Pizzeria.Common.Data;
using Pizzeria.Data.Models;
using Pizzeria.Db.Interface;
using Pizzeria.Service.Interfaces;
using Shouldly;

namespace Pizzeria.Service.Test
{
    public class PizzaServiceTests
    {

        private readonly Mock<IDataAccess> _dataAccess;
        private readonly Mock<INonPizzaItemService> _nonPizzaItemService;
        private readonly Mock<IPizzaCustomizationService> _pizzaCustomizationService;
        private readonly PizzaService _pizzaService;

        public PizzaServiceTests()
        {
            _dataAccess = new Mock<IDataAccess>();
            _nonPizzaItemService = new Mock<INonPizzaItemService>();
            _pizzaCustomizationService = new Mock<IPizzaCustomizationService>();
            _pizzaService = new PizzaService(_dataAccess.Object, _nonPizzaItemService.Object, _pizzaCustomizationService.Object);
        }

        [Fact]
        public async void PizzaService_GetAll_ShouldReturnCountWhenHaveData()
        {
            _dataAccess.Setup(y => y.Get<Pizza>(It.IsAny<string>())).ReturnsAsync(MockData.Pizzas);

            var data = await _pizzaService.GetPizzas();
            data.Count().ShouldBe(2);
        }

        [Fact]
        public async void PizzaService_PlaceOrder_ShouldReturnCorrectPriceForOrder()
        {
            
            _dataAccess.Setup(y => y.Get<Pizza>(It.IsAny<string>())).ReturnsAsync(MockData.Pizzas);
            _pizzaCustomizationService.Setup(y => y.GetAllCustomization()).ReturnsAsync(MockData.Customizations);
            _nonPizzaItemService.Setup(y => y.GetAllNonPizzaItems()).ReturnsAsync(MockData.NonPizzaItem);

            var OrderRequest = new OrderRequest()
            {
                PizzaIds = new int[] { 1 },
                CustomizationIds = new int[] { 2 },
                NonPizzaItems = new int[] { 1 }
            };

            var orderResponse = await _pizzaService.Order(OrderRequest);
            orderResponse.Total.ShouldBe(580);
        }
    }
}