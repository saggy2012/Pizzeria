using Moq;
using Pizzeria.Common.Data;
using Pizzeria.Data.Models;
using Pizzeria.Db.Interface;
using Pizzeria.Service.Interfaces;
using Shouldly;

namespace Pizzeria.Service.Test
{
    public class PizzaCustomizationServiceTest
    {
        private readonly Mock<IDataAccess> _dataAccess;
        private readonly IPizzaCustomizationService _pizzaCustomizationService;

        public PizzaCustomizationServiceTest()
        {
            _dataAccess = new Mock<IDataAccess>();
            _pizzaCustomizationService = new PizzaCustomizationService(_dataAccess.Object);
        }

        [Fact]
        public async void PizzaCustomizationService_GetAll_ShouldReturnCountWhenHaveData()
        {
            _dataAccess.Setup(y => y.Get<Customization>(It.IsAny<string>())).ReturnsAsync(MockData.Customizations);

            var data = await _pizzaCustomizationService.GetAllCustomization();
            data.Count().ShouldBe(2);
        }


        [Fact]
        public async void PizzaCustomizationService_GetAll_ShouldReturnZeroCountWhenHaveNoData()
        {
            List<Customization> customizations = new List<Customization>();
            _dataAccess.Setup(y => y.Get<Customization>(It.IsAny<string>())).ReturnsAsync(customizations);

            var data = await _pizzaCustomizationService.GetAllCustomization();
            data.Count().ShouldBe(0);
        }

    }
}