using Moq;
using Pizzeria.Common.Data;
using Pizzeria.Data.Models;
using Pizzeria.Db.Interface;
using Pizzeria.Service.Interfaces;
using Shouldly;

namespace Pizzeria.Service.Test
{
    public class NonPizzaItemServiceTest
    {
        private readonly Mock<IDataAccess> _dataAccess;
        private readonly INonPizzaItemService _nonPizzaItemService;

        public NonPizzaItemServiceTest()
        {
            _dataAccess = new Mock<IDataAccess>();
            _nonPizzaItemService = new NonPizzaItemService(_dataAccess.Object);
        }

        [Fact]
        public async void PizzaCustomizationService_GetAll_ShouldReturnCountWhenHaveData()
        {
            _dataAccess.Setup(y => y.Get<NonPizzaItem>(It.IsAny<string>())).ReturnsAsync(MockData.NonPizzaItem);

            var data = await _nonPizzaItemService.GetAllNonPizzaItems();
            data.Count().ShouldBe(1);
        }


        [Fact]
        public async void PizzaCustomizationService_GetAll_ShouldReturnZeroCountWhenHaveNoData()
        {
            List<NonPizzaItem> nonPizzaItems = new List<NonPizzaItem>();
            _dataAccess.Setup(y => y.Get<NonPizzaItem>(It.IsAny<string>())).ReturnsAsync(nonPizzaItems);

            var data = await _nonPizzaItemService.GetAllNonPizzaItems();
            data.Count().ShouldBe(0);
        }

    }
}