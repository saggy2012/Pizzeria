﻿namespace Pizzeria.Data.Models
{
    public class BaseItem
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Price { get; set; }
        public string ImgUrl { get; set; }

    }
}
