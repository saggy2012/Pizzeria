﻿namespace Pizzeria.Data.Models
{
    public class Pizza : BaseItem
    {
    }
}
