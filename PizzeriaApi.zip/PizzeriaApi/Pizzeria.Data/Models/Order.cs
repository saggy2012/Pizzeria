﻿namespace Pizzeria.Data.Models
{
    public class OrderResponse : OrderRequest
    {
        public int? Total { get; set; }
    }

    public class OrderRequest
    {
        public Guid Id { get { return Guid.NewGuid(); } }
        public IEnumerable<int> PizzaIds { get; set; }
        public IEnumerable<int> CustomizationIds { get; set; }
        public IEnumerable<int> NonPizzaItems { get; set; }
    }
}
