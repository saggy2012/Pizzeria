﻿namespace Pizzeria.Data.Models
{
    public class NonPizzaItem : BaseItem {
     
    }
}
