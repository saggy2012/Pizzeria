﻿namespace Pizzeria.Data.Models
{
    public enum CustomizationType
    {
        Crust,
        Topping,
        Sauce,
        Cheese
    }
}
