﻿namespace Pizzeria.Data.Models
{
    public class Customization : BaseItem
    {
        public CustomizationType Type { get; set; }
    }
}
