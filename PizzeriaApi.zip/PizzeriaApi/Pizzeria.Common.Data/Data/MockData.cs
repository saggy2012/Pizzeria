﻿using Pizzeria.Data.Models;

namespace Pizzeria.Common.Data
{
    public static class MockData
    {
        public static List<NonPizzaItem> NonPizzaItem = new List<NonPizzaItem>()
            {
                new NonPizzaItem() { Id =1, Name="Pepsi",Price = 60 }
            };

        public static List<Customization> Customizations = new List<Customization>()
            {
                new Customization() { Id =1, Name="Extra Cheese", Type=CustomizationType.Cheese,Price = 30 },
                new Customization() { Id =2, Name="mayo", Type=CustomizationType.Sauce,Price = 20 }
            };

        public static List<Pizza> Pizzas = new List<Pizza>()
            {
                new Pizza(){ Id = 1, Name="Farmhouse",Price = 500},
                new Pizza(){ Id = 2, Name="Chicken Tikka",Price = 650}
            };
    }
}
