﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pizzeria.Db.Interface
{
    public interface IDataAccess
    {
        public Task<IEnumerable<T>> Get<T>(string fileName) where T : class;

        public void Write<T>(string fileName, T modelData) where T : class;
    }
}
