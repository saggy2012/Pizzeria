﻿using Newtonsoft.Json;
using Pizzeria.Db.Interface;

namespace Pizzeria.Db
{
    public class DataAccess : IDataAccess
    {
        public async Task<IEnumerable<T>> Get<T>(string fileName) where T : class
        {
            var streamReader = new StreamReader($"FileDataStorage/{fileName}.json");
            var dataStream = await streamReader.ReadToEndAsync();
            var result = JsonConvert.DeserializeObject<IEnumerable<T>>(dataStream);

            return result ?? Enumerable.Empty<T>();
        }

        public void Write<T>(string fileName, T modelData) where T : class
        {
            File.AppendAllText("FileDataStorage/" + fileName + ".json", JsonConvert.SerializeObject(modelData) + Environment.NewLine);
        }
    }
}